package com.statussaver.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.LruCache;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String HOST = "app.local";
    private static final int REQ_TREE = 42;
    private static final int REQ_PERM = 43;

    // { المفتاح، المسار في أندرويد 11 وما بعده، المسار القديم }
    private static final String[][] SOURCES = {
            {"wa", "Android/media/com.whatsapp/WhatsApp/Media/.Statuses", "WhatsApp/Media/.Statuses"},
            {"wb", "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses", "WhatsApp Business/Media/.Statuses"}
    };

    private WebView web;
    private SharedPreferences prefs;

    // ذاكرة مؤقتة للصور المصغرة
    private final LruCache<String, byte[]> thumbs = new LruCache<String, byte[]>(16 * 1024 * 1024) {
        @Override
        protected int sizeOf(String key, byte[] value) {
            return value.length;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // يسمح بمشاركة الملفات بمسار مباشر في الأجهزة القديمة
        StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder().build());
        prefs = getSharedPreferences("app", MODE_PRIVATE);

        web = new WebView(this);
        web.setBackgroundColor(0xFFD6EFFF);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return serve(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !HOST.equals(request.getUrl().getHost());
            }
        });
        web.loadUrl("https://" + HOST + "/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) js("if (window.onResume) onResume()");
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("handleBack()", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    // ---------- تقديم الصفحة والصور للـ WebView ----------

    private WebResourceResponse serve(Uri url) {
        if (!HOST.equals(url.getHost())) return null;
        String path = url.getPath();
        try {
            if ("/".equals(path) || "/index.html".equals(path)) {
                return new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html"));
            }
            String u = url.getQueryParameter("u");
            if (u == null) return notFound();
            Uri f = Uri.parse(u);
            if ("/media".equals(path)) {
                String mime = getContentResolver().getType(f);
                if (mime == null) mime = mimeFromName(f.getLastPathSegment());
                InputStream in = getContentResolver().openInputStream(f);
                if (in == null) return notFound();
                return new WebResourceResponse(mime, null, in);
            }
            if ("/thumb".equals(path)) {
                byte[] jpg = thumb(f, "video".equals(url.getQueryParameter("t")));
                if (jpg == null) return notFound();
                return new WebResourceResponse("image/jpeg", null, new ByteArrayInputStream(jpg));
            }
        } catch (Exception ignored) {
        }
        return notFound();
    }

    private WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
                new ByteArrayInputStream(new byte[0]));
    }

    private byte[] thumb(Uri f, boolean video) {
        String key = f.toString();
        byte[] cached = thumbs.get(key);
        if (cached != null) return cached;
        Bitmap bm = null;
        try {
            if (video) {
                MediaMetadataRetriever r = new MediaMetadataRetriever();
                try {
                    r.setDataSource(this, f);
                    bm = r.getFrameAtTime(500000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                } finally {
                    try {
                        r.release();
                    } catch (Exception ignored) {
                    }
                }
            } else {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                InputStream in = getContentResolver().openInputStream(f);
                BitmapFactory.decodeStream(in, null, o);
                if (in != null) in.close();
                int sample = 1;
                while (o.outWidth / (sample * 2) >= 360 && o.outHeight / (sample * 2) >= 360) sample *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sample;
                in = getContentResolver().openInputStream(f);
                bm = BitmapFactory.decodeStream(in, null, o2);
                if (in != null) in.close();
            }
            if (bm == null) return null;
            int w = bm.getWidth(), h = bm.getHeight();
            if (w > 360) {
                Bitmap scaled = Bitmap.createScaledBitmap(bm, 360, Math.max(1, h * 360 / w), true);
                if (scaled != bm) bm.recycle();
                bm = scaled;
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.JPEG, 75, out);
            bm.recycle();
            byte[] data = out.toByteArray();
            thumbs.put(key, data);
            return data;
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- الإذن والوصول لمجلد الحالات ----------

    private String source() {
        return prefs.getString("source", "wa");
    }

    private String[] src() {
        return "wb".equals(source()) ? SOURCES[1] : SOURCES[0];
    }

    private boolean useSaf() {
        return Build.VERSION.SDK_INT >= 30;
    }

    private Uri treeUri() {
        String s = prefs.getString("tree_" + source(), null);
        if (s == null) return null;
        Uri t = Uri.parse(s);
        for (UriPermission p : getContentResolver().getPersistedUriPermissions()) {
            if (p.getUri().equals(t) && p.isReadPermission()) return t;
        }
        return null;
    }

    private boolean hasAccess() {
        if (useSaf()) return treeUri() != null;
        if (Build.VERSION.SDK_INT >= 23) {
            return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void requestAccess() {
        if (useSaf()) {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            Uri init = DocumentsContract.buildDocumentUri(
                    "com.android.externalstorage.documents", "primary:" + src()[1]);
            i.putExtra(DocumentsContract.EXTRA_INITIAL_URI, init);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            try {
                startActivityForResult(i, REQ_TREE);
            } catch (Exception e) {
                js("onAccess(false)");
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            List<String> p = new ArrayList<>();
            p.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            if (Build.VERSION.SDK_INT <= 28) p.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            requestPermissions(p.toArray(new String[0]), REQ_PERM);
        } else {
            js("onAccess(true)");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_TREE) return;
        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri t = data.getData();
            String id = DocumentsContract.getTreeDocumentId(t);
            if (id == null || !id.endsWith(".Statuses")) {
                js("onAccess('wrong')");
                return;
            }
            try {
                getContentResolver().takePersistableUriPermission(t, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {
            }
            prefs.edit().putString("tree_" + source(), t.toString()).apply();
            js("onAccess(true)");
        } else {
            js("onAccess(false)");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_PERM) js("onAccess(" + hasAccess() + ")");
    }

    // ---------- قراءة الحالات ----------

    private JSONArray listItems() throws Exception {
        Set<String> saved = prefs.getStringSet("saved", new HashSet<String>());
        Set<String> names = new HashSet<>();
        List<JSONObject> out = new ArrayList<>();

        if (useSaf()) {
            Uri t = treeUri();
            if (t != null) {
                Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(t, DocumentsContract.getTreeDocumentId(t));
                String[] cols = {
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE,
                        DocumentsContract.Document.COLUMN_SIZE,
                        DocumentsContract.Document.COLUMN_LAST_MODIFIED
                };
                Cursor c = getContentResolver().query(children, cols, null, null, null);
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            String name = c.getString(1);
                            String mime = c.getString(2);
                            String type = typeOf(name, mime);
                            if (type == null || !names.add(name)) continue;
                            Uri doc = DocumentsContract.buildDocumentUriUsingTree(t, c.getString(0));
                            out.add(item(doc, name, type, mime, c.getLong(3), c.getLong(4), saved));
                        }
                    } finally {
                        c.close();
                    }
                }
            }
        } else {
            File root = Environment.getExternalStorageDirectory();
            for (String p : new String[]{src()[1], src()[2]}) {
                File[] files = new File(root, p).listFiles();
                if (files == null) continue;
                for (File f : files) {
                    String name = f.getName();
                    String type = typeOf(name, null);
                    if (type == null || !f.isFile() || !names.add(name)) continue;
                    out.add(item(Uri.fromFile(f), name, type, null, f.length(), f.lastModified(), saved));
                }
            }
        }

        Collections.sort(out, (a, b) -> Long.compare(b.optLong("d"), a.optLong("d")));
        JSONArray arr = new JSONArray();
        for (JSONObject o : out) arr.put(o);
        return arr;
    }

    private JSONObject item(Uri u, String name, String type, String mime, long size, long date, Set<String> saved) throws Exception {
        JSONObject o = new JSONObject();
        o.put("u", u.toString());
        o.put("n", name);
        o.put("t", type);
        o.put("m", (mime == null || mime.isEmpty()) ? mimeFromName(name) : mime);
        o.put("s", size);
        o.put("d", date);
        o.put("saved", saved.contains(name));
        return o;
    }

    private static String typeOf(String name, String mime) {
        String n = name == null ? "" : name.toLowerCase();
        if (n.endsWith(".nomedia")) return null;
        if ((mime != null && mime.startsWith("image/")) || n.matches(".*\\.(jpe?g|png|webp|gif)$")) return "image";
        if ((mime != null && mime.startsWith("video/")) || n.matches(".*\\.(mp4|3gp|mkv|webm|mov)$")) return "video";
        return null;
    }

    private static String mimeFromName(String name) {
        String n = name == null ? "" : name.toLowerCase();
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".mp4")) return "video/mp4";
        if (n.endsWith(".3gp")) return "video/3gpp";
        if (n.endsWith(".mkv")) return "video/x-matroska";
        if (n.endsWith(".webm")) return "video/webm";
        if (n.endsWith(".mov")) return "video/quicktime";
        return "application/octet-stream";
    }

    // ---------- الحفظ في المعرض ----------

    private boolean saveOne(Uri src, String name, String mime, boolean video) {
        ContentResolver cr = getContentResolver();
        try (InputStream in = cr.openInputStream(src)) {
            if (in == null) return false;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH,
                        (video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES) + "/StatusSaver");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                Uri dst = cr.insert(collection, v);
                if (dst == null) return false;
                try (OutputStream out = cr.openOutputStream(dst)) {
                    if (out == null) return false;
                    copy(in, out);
                }
                v.clear();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                cr.update(dst, v, null, null);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(
                        video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES), "StatusSaver");
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, name);
                try (OutputStream out = new FileOutputStream(f)) {
                    copy(in, out);
                }
                MediaScannerConnection.scanFile(this, new String[]{f.getAbsolutePath()}, null, null);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }

    private void js(final String code) {
        web.post(() -> web.evaluateJavascript(code, null));
    }

    // ---------- الجسر بين الصفحة والتطبيق ----------

    public class Bridge {

        @JavascriptInterface
        public String state() {
            try {
                JSONObject o = new JSONObject();
                o.put("source", source());
                o.put("access", hasAccess());
                o.put("saf", useSaf());
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void setSource(String s) {
            prefs.edit().putString("source", "wb".equals(s) ? "wb" : "wa").apply();
        }

        @JavascriptInterface
        public void requestAccess() {
            runOnUiThread(() -> MainActivity.this.requestAccess());
        }

        @JavascriptInterface
        public void list() {
            new Thread(() -> {
                String json;
                try {
                    json = listItems().toString();
                } catch (Exception e) {
                    json = "[]";
                }
                js("onList(" + json + ")");
            }).start();
        }

        @JavascriptInterface
        public void save(final String jsonArr) {
            new Thread(() -> {
                int ok = 0, fail = 0;
                try {
                    JSONArray a = new JSONArray(jsonArr);
                    Set<String> saved = new HashSet<>(prefs.getStringSet("saved", new HashSet<String>()));
                    for (int i = 0; i < a.length(); i++) {
                        JSONObject o = a.getJSONObject(i);
                        String name = o.getString("n");
                        boolean done = saveOne(Uri.parse(o.getString("u")), name, o.getString("m"),
                                "video".equals(o.getString("t")));
                        if (done) {
                            ok++;
                            saved.add(name);
                        } else {
                            fail++;
                        }
                    }
                    prefs.edit().putStringSet("saved", saved).apply();
                } catch (Exception ignored) {
                }
                js("onSaved(" + ok + "," + fail + ")");
            }).start();
        }

        @JavascriptInterface
        public void share(String u, String mime) {
            final Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_STREAM, Uri.parse(u));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            runOnUiThread(() -> {
                try {
                    startActivity(Intent.createChooser(i, null));
                } catch (Exception e) {
                    js("onNativeError('share')");
                }
            });
        }

        @JavascriptInterface
        public void play(String u, String mime) {
            final Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(u), mime);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            runOnUiThread(() -> {
                try {
                    startActivity(i);
                } catch (Exception e) {
                    js("onNativeError('play')");
                }
            });
        }
    }
}
